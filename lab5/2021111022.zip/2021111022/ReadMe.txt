Readme.txt contains the explanation of codes 

In Question 1
we find the substring and concat it with the name column along with braces

In Question 2
we use case statements 
if N is Root, root word is concatted with N, similarly for all 
here order by asc is used to sort the result in ascending order.  